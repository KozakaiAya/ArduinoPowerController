Arduino-Ping
============

ICMP ping library for the Arduino